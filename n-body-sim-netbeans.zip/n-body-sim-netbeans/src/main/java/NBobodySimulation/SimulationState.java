package NBobodySimulation;

public enum SimulationState {
    ACTIVE,
    INACTIVE,
    PAUSED,
}

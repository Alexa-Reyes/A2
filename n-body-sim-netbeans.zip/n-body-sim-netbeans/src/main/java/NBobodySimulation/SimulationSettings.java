package NBobodySimulation;

public class SimulationSettings {

}
